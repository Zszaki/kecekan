const cells = document.querySelectorAll(".cell");
const statusText = document.getElementById("status");
const restartBtn = document.getElementById("restart");

let currentPlayer = "X";
let gameActive = true;
let board = ["","","","","","","","",""];

const winPatterns = [
[0,1,2],
[3,4,5],
[6,7,8],
[0,3,6],
[1,4,7],
[2,5,8],
[0,4,8],
[2,4,6]
];

cells.forEach(cell=>{
    cell.addEventListener("click", handleClick);
});

restartBtn.addEventListener("click", restartGame);

function handleClick(){
    const index = this.dataset.index;

    if(board[index] !== "" || !gameActive) return;

    board[index] = currentPlayer;
    this.textContent = currentPlayer;
    this.classList.add(currentPlayer.toLowerCase());

    checkWinner();

    currentPlayer = currentPlayer === "X" ? "O" : "X";
    statusText.textContent = `Player ${currentPlayer} Turn`;
}

function checkWinner(){

    for(let pattern of winPatterns){

        const [a,b,c] = pattern;

        if(board[a] && board[a] === board[b] && board[a] === board[c]){

            cells[a].classList.add("winner");
            cells[b].classList.add("winner");
            cells[c].classList.add("winner");

            statusText.textContent = `Player ${board[a]} Wins!`;
            gameActive = false;
            return;
        }
    }

    if(!board.includes("")){
        statusText.textContent = "Draw!";
        gameActive = false;
    }
}

function restartGame(){

    board = ["","","","","","","","",""];
    gameActive = true;
    currentPlayer = "X";
    statusText.textContent = "Player X Turn";

    cells.forEach(cell=>{
        cell.textContent="";
        cell.classList.remove("x","o","winner");
    });

}